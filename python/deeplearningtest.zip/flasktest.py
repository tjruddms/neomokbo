import io
from flask import Flask, jsonify, request
import numpy as np
import pandas as pd
from keras.models import load_model
import librosa
import json
import matplotlib.pyplot as plt
from flask_cors import CORS

app = Flask(__name__)
CORS(app)

mymodel = load_model("neomokbo.h5")

def CutSoundHalfSec(datas, sr):
    data = pd.DataFrame(columns=["feature", "label"])
    adddata = pd.DataFrame(columns=["feature", "label"])
    for i in range(0, len(datas) // (sr // 1)):
        segment = datas[(sr // 1) * i : (sr // 1) * (i + 1)]
        if len(segment) == sr // 1:  # 0.5초 길이인 경우에만 처리
            mfcc = librosa.feature.mfcc(y=segment, sr=sr, n_mfcc=20)
            adddata = pd.DataFrame({"feature": [mfcc]})
            data = pd.concat([data, adddata])
    return data

def Mel_S(y, sr):
    S = librosa.feature.melspectrogram(y=y)

    print("Wav length: {}, Mel_S shape:{}".format(len(y) / sr, np.shape(S)))

    plt.figure(figsize=(10, 4))
    librosa.display.specshow(
        librosa.power_to_db(S, ref=np.max), y_axis="mel", sr=sr, x_axis="time"
    )
    plt.colorbar(format="%+2.0f dB")
    plt.title("Mel-Spectrogram")
    plt.tight_layout()
    plt.savefig("Mel-Spectrogram example.png")
    plt.show()
    plt.clf()
    return S

@app.route('/data', methods=['POST'])
def receive_wav_data():
    wav_data = request.data
    # print(wav_data)
    # print(type(wav_data))
    # 데이터 디코딩 및 파싱
    data_str = wav_data.decode('utf-8')
    data_dict = json.loads(data_str)
    # print(type(data_dict))

    # 필요한 배열 부분 추출
    array_data = data_dict.get('data', [])
    # print(type(array_data))
    # print(len(array_data))
    # print(array_data[:10])
    # print("shape : ",array_data.shape)

    # plt.figure(figsize=(15,5))
    # plt.plot(array_data[:22050])
    # plt.yticks([-0.1,0.1])
    # plt.savefig('test.png')
    # Mel_S(np.array(array_data[:22050]),22050)
    # plt.clf()

    # print(len(array_data))
    preddata = CutSoundHalfSec(np.array(array_data), 22050)
    # print(preddata)

    # print(adddata)
    # print(type(adddata))

    pred_test = mymodel.predict(np.array([preddata.feature.iloc[0]]))
    print("환경음 : ",int(pred_test[0][0]*100),"%")
    print("경적소리 : ",int(pred_test[0][1]*100),"%")
    print("개소리 : ",int(pred_test[0][2]*100),"%")
    print("사이렌소리 : ",int(pred_test[0][3]*100),"%")


    # 가장 큰 값 찾아서 인덱스 반환

    # 가장 큰 값의 인덱스 찾기
    pred_index = np.argmax(pred_test[0])

    # 각 클래스에 해당하는 확률 값 출력
    class_labels = ["환경음", "경적소리", "개소리", "사이렌소리"]
    for i, label in enumerate(class_labels):
        print(label, ":", int(pred_test[0][i] * 100), "%")

    return class_labels[pred_index], 200

if __name__ == "__main__":
    app.run(debug=True, host='127.0.0.1', port=3333)
